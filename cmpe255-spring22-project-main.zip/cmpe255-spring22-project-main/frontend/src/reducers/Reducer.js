/* eslint-disable no-param-reassign */
import { createSlice } from '@reduxjs/toolkit';

export const Reducer = createSlice({
  name: 'group',
  initialState: {
  },
  extraReducers: {
   
  },
});

export default Reducer.reducer;
