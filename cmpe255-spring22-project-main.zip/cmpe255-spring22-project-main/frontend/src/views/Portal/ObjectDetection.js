/* eslint-disable no-restricted-syntax */
/* eslint-disable react/no-string-refs */
/* eslint-disable react/jsx-no-duplicate-props */
/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable no-unused-vars */
/* eslint-disable import/no-named-as-default-member */
/* eslint-disable react/react-in-jsx-scope */
/* eslint-disable import/no-named-as-default */
/* eslint-disable react/destructuring-assignment */
/* eslint-disable constructor-super */
import React, { useState, useEffect } from 'react';
// import { Redirect } from 'react-router-dom';
import Button from '@material-ui/core/Button';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import axios from 'axios';
import  TextField from '@material-ui/core/TextField';
import { Typography } from '@material-ui/core';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardMedia from '@material-ui/core/CardMedia';
import CardContent from '@material-ui/core/CardContent';
import Container from 'react-bootstrap/Container';
import { Form, Carousel } from 'react-bootstrap';
import Dropdown from 'react-bootstrap/Dropdown';

// eslint-disable-next-line arrow-body-style

const ObjectDetection = () => {
  const [imageList, addImage] = useState([]);
  const [imgCounter, addCounter] = useState(0);
  const [showImage, addShowImage] = useState([]);
  const [resp, changeResp] = useState(false);
  const [responseText, changeText] = useState('');
  const [responseURL, changeURL] = useState('');

  const ImageTake = async (event) => {
    const url = URL.createObjectURL(event.target.files[0]);
    addShowImage([url]);
    addCounter(imgCounter + 1);
    addImage([
      ...imageList,
      {
        id: `image${imgCounter}`,
        file: event.target.files[0],
        file_name: event.target.files[0].name,
      },
    ]);
  };
  const submit = async () => {
    if (imageList.length > 0){
      const formData = new FormData();
      formData.append('profileImage',imageList[0].file,imageList[0].file_name);
      const config = {
        headers: { 
          'content-type': 'multipart/form-data'
        }
      }
      const response = await axios.post('http://localhost:5000/imageadd',formData,config)
      if (response.status === 200) {
        changeText(response.data.text)
        changeURL("http://localhost:8080/"+response.data.a)
        changeResp(true)
      }
    }
  }
  const onClear = () => {
    changeResp(false)
    addShowImage([])
    addImage([])
  }
  return (
    <>
    <Row style={{ "margin": "auto",
    "margin-bottom": "3rem",
    "margin-left": "28rem",
    "margin-top": "3rem"}}>
      <h1>
      CMPE-255 Image Detection
      </h1>
    </Row>
          <Row>
            <Col lg={1}/>
            <Col lg={4}>
          <Card style={{ height:"30rem",width:"30rem",margin:"3rem" }}>
          <CardHeader
                title="Add Images"
              />
          <form className="form-signin" style={{ marginTop: '5%' }}>
              <Row>
                <Col>
                  <Form>
                    <Form.File id="custom-file" label="Add Your Image Here !" custom onChange={ImageTake} />
                    <br />
                    </Form>
                </Col>
              </Row>
              <Row style={{ marginTop: '1%' }}>
                <Button
                  variant="primary"
                  style={{
                    'background-color': 'lightsteelblue',
                    color: '#ffffff',
                    'border-color': '#0579d3',
                  }}
                  onClick={() => submit()}
                >
                  Predict
                </Button>
                <Button
                  variant="secondary"
                  style={{
                    'background-color': 'lightsteelblue',
                    color: '#ffffff',
                    'border-color': '#0579d3',
                    marginLeft: "2%"
                  }}
                  onClick={() => onClear()}
                >
                  Delete
                </Button>
              </Row>
              <Row>
              <Col>
              {showImage.length === 0 ? null : (
                <Carousel
                  style={{
                    maxWidth: '1000px',
                    maxHeight: '750px',
                    textAlign: 'center',
                  }}
                >
                  {showImage.map((image) => (
                    <Carousel.Item>
                      <img
                        style={{ maxWidth: '400px', maxHeight: '200px', minHeight: '200px' }}
                        src={image}
                        className="d-block w-100"
                      />
                    </Carousel.Item>
                  ))}
                </Carousel>
              )}
              </Col>
          </Row> 
          </form>
          </Card>
          </Col>
            <Col lg={1}/>
          <Col lg={4}>  
          <Card style={{ height:"15rem",width:"30rem",margin:"3rem" }} >
              {responseURL && <img src={responseURL} style={{ height:"100%",width:"100%"}}/>}
          </Card>

          
          <Card style={{ height:"15rem",width:"30rem",margin:"3rem" }} >
              <CardContent>
                <Typography variant="body2" color="textSecondary" component="p">Digitized Text : {responseText}
                </Typography>
              </CardContent>
          </Card>

          </Col>
          </Row>
    </>
  );
};

export default ObjectDetection;
