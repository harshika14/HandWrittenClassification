Project topic-

Turning Handwritten Documents into Digitized Versions

This type of project is a perfect way to practice deep learning and neural networks — essentials for image recognition in machine learning. Beginners can also learn how to turn pixel data into images, 
as well as how to use logistic regression and MNIST datasets.

Team Members:


Sakshi	Mishra |015721810

Arpitha Srinivas |015908880

Snigdha	Chaturvedi |015957435

Harshika Shrivastava |016019120

Datasets-
[MNIST Dataset](https://www.kaggle.com/sachinpatel21/az-handwritten-alphabets-in-csv-format)

Dataset for alphabet-
[kaggle dataset](https://www.kaggle.com/datasets/sachinpatel21/az-handwritten-alphabets-in-csv-format)

Weekly Plan : https://docs.google.com/document/d/1gHxheGr6TFOODLdS-Vq3G1Ji2AOmi8a3QeQ9eVB7VKc/edit?usp=sharing

